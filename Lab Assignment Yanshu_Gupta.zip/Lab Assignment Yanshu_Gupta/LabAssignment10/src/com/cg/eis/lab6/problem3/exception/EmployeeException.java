package com.cg.eis.lab6.problem3.exception;

public class EmployeeException extends Exception{

}
