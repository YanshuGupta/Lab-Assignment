package com.capagemini.lab4.Exception;

public class InsuffiecientBalanceException extends Exception{

}
