package problem7.exception;

public class EmployeeException extends Exception{

}
