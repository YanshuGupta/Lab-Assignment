package com.cg.eis.lab6.problem1.Exception;

public class InvailidNameException extends Exception {

}
